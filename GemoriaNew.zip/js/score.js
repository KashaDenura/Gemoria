let score = 0;

let level = 1;

let moves = 50;

let targetScore = 250;

let life = 3;

let levelMoves = 0;

const scoreText = document.getElementById("scoreText");

const popup = document.getElementById("popup");
const popupTitle = document.getElementById("popupTitle");
const popupMessage = document.getElementById("popupMessage");
const popupButton = document.getElementById("popupButton");

function updateHUD() {

    scoreText.textContent = score;

    document.getElementById("levelText").textContent = level;

    document.getElementById("movesText").textContent = moves;

    document.getElementById("targetText").textContent = targetScore;

document.getElementById("lifeText").textContent =
"❤️".repeat(life) + "🤍".repeat(3-life);

}

function getStars() {

    if (score >= targetScore * 2) {

        return "⭐⭐⭐";

    }

    if (score >= targetScore * 1.5) {

        return "⭐⭐";

    }

    return "⭐";

}

function showPopup(title, message, buttonText, callback) {

    popupTitle.textContent = title;

    popupMessage.innerHTML = message;

    popupButton.textContent = buttonText;

    gameLocked = true;

    popup.style.display = "flex";

    popupButton.onclick = () => {

        popup.style.display = "none";

        gameLocked = false;

        callback();

    };

}

function levelComplete() {

    showPopup(

        "🎉 LEVEL COMPLETE!",

        "Level : " + level +
        "<br>Score : " + score +
        "<br><br>" + getMoveStars(),

        "Next Level",

        () => {

            if (navigator.vibrate) {

                navigator.vibrate([120, 50, 120]);

            }

            level++;
            
            levelMoves = 0;


            moves = 50;

            targetScore = Math.floor(targetScore * 1.7);

            createBoard();

            updateHUD();

        }

    );

}

function gameOver() {

    showPopup(

        "💀 GAME OVER",

        "Level : " + level +
        "<br>Score : " + score,

        "Main Lagi",

        () => {

            if (navigator.vibrate) {

                navigator.vibrate(250);

            }

            level = 1;

            score = 0;

            moves = 50;

            targetScore = 250;

            createBoard();

            updateHUD();

        }

    );

}

function checkGameState() {

    // Berhasil menyelesaikan level
    if (score >= targetScore) {

        levelComplete();
        return;

    }

    // Jatah moves habis
    if (moves <= 0) {

        life--;

        if (life <= 0) {

            gameOver();
            return;

        }

        // Masih punya life
        moves = 50;

        updateHUD();

        showPopup(
            "💔 LIFE BERKURANG",
            "Sisa Life : " + life,
            "Lanjut",
            () => {}
        );

    }

}

function getMoveStars() {

    const star3 = Math.max(10, Math.floor(30 + (level - 1) * 15));
    const star2 = star3 + 10;
    const star1 = star2 + 10;

    if (levelMoves <= star3) {

        return "⭐⭐⭐";

    }

    if (levelMoves <= star2) {

        return "⭐⭐";

    }

    if (levelMoves <= star1) {

        return "⭐";

    }

    return "";

}