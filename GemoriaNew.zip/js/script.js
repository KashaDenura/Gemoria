const playBtn = document.getElementById("playBtn");
const menu = document.getElementById("menu");
const game = document.getElementById("game");
const board = document.getElementById("board");

const SIZE = 8;

let boardData = [];

let firstTile = null;
let startX = 0;
let startY = 0;

let gameLocked = false;

playBtn.addEventListener("click", startGame);

function startGame() {

    score = 0;
    level = 1;
    moves = 50;
    targetScore = 500;

    gameLocked = false;

    menu.style.display = "none";
    game.style.display = "block";

    createBoard();

    updateHUD();

}